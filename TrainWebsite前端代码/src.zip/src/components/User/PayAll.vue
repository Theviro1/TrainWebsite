<template>
  <el-container class="home_container">
    <!-- 头部区域 -->
    <el-header>
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/MainPage' }" class="myColor">首页</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/payall' }" class="myColor">个人页面</el-breadcrumb-item>
      </el-breadcrumb>
      <el-button @click="logout">退出</el-button>
    </el-header>
    <!-- 页面主体区域 -->
    <el-container>
      <!-- 侧边栏 -->
      <el-aside width="200px" style="background-color: white" >
        <!-- 侧边栏菜单区域 -->
        <el-menu :default-openeds="['1','2']" :router="true">
          <!-- 一级菜单 -->
          <el-submenu index="1">
            <template slot="title"><i class="el-icon-menu"></i>个人中心</template>
            <el-menu-item-group>
              <el-menu-item index="/UserMain">个人主页</el-menu-item>
              <el-menu-item index="/UserMessage">信息修改</el-menu-item>
              <el-menu-item index="/Recharge">充值</el-menu-item>
              <el-menu-item index="/Message">消息</el-menu-item>
            </el-menu-item-group>
          </el-submenu>
          <el-submenu index="2">
            <template slot="title"><i class="el-icon-message"></i>订单信息</template>
            <el-menu-item-group>
              <el-menu-item index="/PayingOrder">当前订单</el-menu-item>
              <el-menu-item index="/PayedOrder">历史订单</el-menu-item>
              <el-menu-item index="/InvalidOrder">失效订单</el-menu-item>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-aside>
      <el-main>
        <router-view :userid="userid"></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
import axios from "axios"
export default {
  data() {
    return {
      username: '',
      userid: '',
    }
  },
  // created () {
  //     this.GetUser();
  // },
  methods: {
    logout() {
      window.sessionStorage.clear()
      this.$router.push('/UserLogin')
    },
    // 获取所有的菜单数据
    // async GetUser(){
    //   await axios
    //   .get("http://localhost:80/users/"+this.$route.query.id)
    //   .then((res) => {
    //     console.log(res)
    //     if (res.data.success == true) {
    //       this.username=res.data.data.name;
    //       this.userid=res.data.data.id;
    //     } else {
    //       this.$message({
    //         message: res.data.message,
    //         type: 'error',
    //       })
    //     }
    //   })
    // },
    // 点击按钮，切换菜单的折叠与展开
  }
}
</script>
<style lang="less" scoped>
.home_container {
  height: 100%;
}

.myColor /deep/ .el-breadcrumb__inner {
  color: black;
}

.el-header {
  background-color: white;
  // 给头部设置一下弹性布局
  display: flex;
  // 让它贴标左右对齐
  justify-content: space-between;
  // 清空图片左侧padding
  padding-left: 0;
  // 按钮居中
  align-items: center;
  // 文本颜色
  color: #fff;
  // 设置文本字体大小
  font-size: 20px;

  // 嵌套
  >div {
    // 弹性布局
    display: flex;
    // 纵向上居中对齐
    align-items: center;

    // 给文本和图片添加间距，使用类选择器
    span {
      margin-left: 15px;
    }
  }
}

.el-header {
  background-color: #e5efe2;
  color: #333;
  line-height: 60px;
}

.el-aside {
  color: #333;
}

.router-link-active {
  text-decoration: none;
}

.alink {

  text-decoration: none;
}

.iconfont {
  margin-right: 10px;
}

.toggle-button {
  // 添加背景颜色
  background-color: grey;
  // 设置文本大小
  font-size: 10px;
  // 设置文本行高
  line-height: 24px;
  // 设置文本颜色
  color: #fff;
  // 设置文本居中
  text-align: center;
  // 设置文本间距
  letter-spacing: 0.2em;
  // 设置鼠标悬浮变小手效果
  cursor: pointer;
}</style>