<template>
  <div class="text_1">
    <h3>Welcome</h3>
  </div>
</template>

<style>
.text_1 {
  margin-left: 0px;
}
</style>
