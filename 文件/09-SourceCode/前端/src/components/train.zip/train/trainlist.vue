<template>
  <div>
      <!-- 面包屑导航 -->
      <el-breadcrumb class="breadcrumb" separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>火车信息</el-breadcrumb-item>
          <el-breadcrumb-item>可选择列表</el-breadcrumb-item>
      </el-breadcrumb>

      <!-- 卡片视图 -->
      <el-card>
        <span class="p1">出发地</span>
        <el-select class="test" v-model="departureid" clearable placeholder="请选择出发地">   
          <el-option v-for="item in departurePlatforms" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <span class="p2">目的地</span>
        <el-select class="test" v-model="arrivalid" clearable placeholder="请选择目的地">   
          <el-option v-for="item in arrivalPlatforms" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <span class="p1">发车日期</span>
        <el-date-picker class="test" v-model="time" type="daterange" align="right" unlink-panels range-separator="至"     start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerOptions">
        </el-date-picker>
        <el-button type="warning" class="query" icon="el-icon-search" @click="ticketQuery()" >查询</el-button>
      </el-card>
      <!-- Table视图 --> 
      <el-table :data="trainsList" border stripe height="580" highlight-current-row  @row-click="getTrainid" >
        <el-table-column type="index" label="序号" width="100px"></el-table-column>
        <el-table-column label="火车序号" prop="id" width="150px"></el-table-column>
        <el-table-column label="起始站"  width="150px">
          <template #default="scope">
            <div>{{IdChange(scope.row.departurePlatformId)}}</div>
          </template>
        </el-table-column>
        <el-table-column label="终点站" width="150px">
          <template #default="scope">
            <div>{{IdChange(scope.row.arrivalPlatformId)}}</div>
          </template>
        </el-table-column>
        <el-table-column label="发车时间" prop="departureTime" width="350px" ></el-table-column>
        <el-table-column label="终点时间" prop="arrivalTime" width="350px"></el-table-column>
        <el-table-column label="经停站数" prop="platformNum" width="100px"></el-table-column>
        <el-table-column label="查看车次信息" width="150px">
          <template slot-scope="{}">
            <el-tooltip effect="dark" content="查询" placement="top">
            <el-button type="primary" icon="el-icon-search" size="mini">查看</el-button>
            </el-tooltip>
         </template>
        </el-table-column>
      </el-table>

  </div>
  
</template>

<script>
import axios from 'axios';
export default {
  methods: {
    getTrainid(row){
      this.trainid = row.id;
      this.arrivalPlatformId = row.arrivalPlatformId
      this.departurePlatformId = row.departurePlatformId
      this.departureTime = row.departureTime
      this.arrivalTime = row.arrivalTime
      this.platformNum = row.platformNum
      console.log(this.trainid)
      console.log(this.departurePlatformId)
      console.log(this.arrivalPlatformId)
      this.$store.commit('savetrainid', this.trainid);
      this.$store.commit('savedeparturePlatformId', this.departurePlatformId);
      this.$store.commit('savearrivalPlatformId', this.arrivalPlatformId);
      this.$store.commit('savedepartureTime',this.departureTime);
      this.$store.commit('savearrivalTime',this.arrivalTime);
      this.$store.commit('saveplatformNum',this.platformNum);
      this.changeTrainInf();
    },
    IdChange(id){
      if(id==1)
        return '北京'
      if(id==2)
        return '天津'
      if(id==3)
        return '济南'
      if(id==4)
        return '南京'
      if(id==5)
        return '杭州'
      if(id==6)
        return '上海'
      if(id==7)
        return '福州'
      if(id==8)
        return '厦门'
      if(id==9)
        return '海口'
      if(id==10)
        return '三亚'
    },
    changeTrainInf(){
      this.$router.push("/traininf");
    },
    async getTrainsList() {
      await axios.get('http://localhost:80/train').then((res) => {
        console.log(1);
        console.log(res);
        const { data } = res.data
        console.log(data);
        this.trainsList = data;
        console.log(this.userList.length);
      })
    },
    async ticketQuery(){
      await axios.get('http://localhost:80/train/search',{params:{departurePlatformId:departurePlatformId,arrivalPlatformId:arrivalPlatformid,departureDate:time}}).then((res) => {
        const { data } = res.data
        this.trainsList = data
      })
    }
  },
  data(){
    return{
      trainid:'',
      arrivalid:'',
      departureid:'',
      arrivalPlatformId:'',
      departurePlatformId:'',
      departureTime:'',
      arrivalTime:'',
      platformNum:'',
      time:'',
      trainsList:[],
      arrivalPlatforms: [{
          value: 1,
          label: '北京'
        }, {
          value: 2,
          label: '天津'
        }, {
          value: 3,
          label: '济南'
        }, {
          value: 4,
          label: '南京'
        }, {
          value: 5,
          label: '杭州'
        }, {
          value: 6,
          label: '上海'
        }, {
          value: 7,
          label: '福州'
        }, {
          value: 8,
          label: '厦门'
        }, {
          value: 9,
          label: '海口'
        }, {
          value: 10,
          label: '三亚'
      }],
      departurePlatforms:[{
        value: 1,
          label: '北京'
        }, {
          value: 2,
          label: '天津'
        }, {
          value: 3,
          label: '济南'
        }, {
          value: 4,
          label: '南京'
        }, {
          value: 5,
          label: '杭州'
        }, {
          value: 6,
          label: '上海'
        }, {
          value: 7,
          label: '福州'
        }, {
          value: 8,
          label: '厦门'
        }, {
          value: 9,
          label: '海口'
        }, {
          value: 10,
          label: '三亚'
      }],
      pickerOptions: {
        shortcuts: [
          {
            text: '近三天',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 2)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 6)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '近一月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              end.setTime(start.getTime() + 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
    }
  },
  created(){
    this.getTrainsList();
  }
}
</script>

<style scoped>
.el-table{
  margin-left:70px;
  margin-top: 70px;
  font-size: 14px;
}
.el-card{
  margin-left:50px;
  margin-right:50px;
  margin-top:35px;
}
.breadcrumb{
  margin-top:30px;
  margin-left:30px;
}
.query{
  margin-left: 50px;
}
.p1{
  margin-left: 90px;
}
.p2{
  margin-left: 20px;
}
.test{
  margin-left: 20px;
  /* background:rgb(183, 229, 219) */
}

.text {
  font-size: 14px;
}
 
.item {
  padding: 18px 0;
}
</style>